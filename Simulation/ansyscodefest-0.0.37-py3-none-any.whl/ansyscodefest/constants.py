from collections import namedtuple
from enum import IntEnum
from math import sqrt

Material = namedtuple('Material',
                      ['name', 'density', 'elastic_modulus', 'poissons_ratio',
                       'yield_strength', 'price_per_kg', 'id'])
BeamDimensions = namedtuple('BeamDimensions',
                            ['name', 'shape', 'dimensions', 'material'])

# Steel
# Density  = 7850 Kg/m^3
# Elastic Modulus = 210 GPa
# Poisson's Ratio = 0.29
# Yield Strength = 330 GPa
STEEL = Material('Steel', 7850., 210.e9, 0.29, 330.e6, 1.2, 1)
#  Copper, cast (h.c. copper)
COPPER = Material('Copper', 8940., 125.e9, 0.345, 30.e6, 9.3, 2)
# Al 6061 T6
ALUMINUM = Material('Aluminum', 2800., 70.e9, 0.33, 270.e6, 3.5, 3)
EXPANDED_POLYSTYRENE = Material('Expanded Polystyrene', 24., .007e9, .275,
                                .175e6, 3., 4)
TITANIUM = Material('Titanium', 4500., 110.e9, 0.35, 500.e6, 15., 5)
IRON = Material('Cast Iron', 7000., 90.e9, 0.26, 80.e6, 0.5, 6)
DIAMOND = Material('Diamond', 3500., 1100.e9, 0.2, 2850.e6, 400000., 7)
CONCRETE = Material('Concrete', 650., 15.e9, 0.185, 1.e6, 0.07, 8)
GRANITE = Material('Granite', 3000., 60.e9, 0.2, 17.e6, 3.5, 9)
MARBLE = Material('Marble', 2800., 60.e9, 0.18, 8.e6, 0.71, 10)
SANDSTONE = Material('Sandstone', 2400., 19.5e9, 0.255, 13.e6, 0.5, 11)
ICE = Material('Ice', 925., 9.15e9, 0.365, 6.5e6, 0.25, 12)
OAK = Material('Oak', 800., 15.e9, 0.375, 70.e6, 2.3, 13)
PINE = Material('Pine', 400., 9.e9, 0.375, 32.e6, 1.0, 14)
BEECH = Material('Beech', 750., 15.e9, 0.375, 58.e6, 2.4, 15)
CORK = Material('Cork', 150., 0.02e9, 0.1, 0.5e6, 5., 16)

MATERIALS = {m.id: m for m in
             [STEEL, COPPER, ALUMINUM, EXPANDED_POLYSTYRENE, TITANIUM, IRON,
              DIAMOND, CONCRETE, GRANITE, MARBLE, SANDSTONE, ICE, OAK, PINE,
              BEECH, CORK]}
MATERIAL_IDS = list(MATERIALS.keys())
MAX_EDGE_LENGTH = sqrt(2.)
STARTING_LIVES = 1000


class BeamXn(IntEnum):
    """Beam cross-section enum.

    In PyMAPDL the beam cross-sections correspond to the following sectypes.

    RECTANGLE = RECT
    RECTANGLETUBE = HREC
    CSOLID = CIRCLE
    CTUBE = CYLINDER
    """
    RECTANGLE = 1
    CIRCLE = 2
    CYLINDER = 3
    RECTANGLETUBE = 4
