import json
import pathlib
import uuid
from collections import namedtuple
from dataclasses import dataclass
from enum import IntEnum
from importlib.resources import files
from math import pi, cos, sin
from math import sqrt
from string import Template
from typing import Union, Iterable, List, Dict, Tuple, Set

import matplotlib as mpl
import matplotlib.pyplot as plt
from ansys.mapdl.core import launch_mapdl
from ansys.mapdl.core.mapdl import _MapdlCore
from matplotlib import cm
from mpl_toolkits.axes_grid1 import make_axes_locatable

from . import chambers
from . import story
from .constants import STARTING_LIVES, BeamXn, MATERIALS, MAX_EDGE_LENGTH, \
    STEEL, PINE, CORK, COPPER, CONCRETE, BEECH, EXPANDED_POLYSTYRENE, DIAMOND, \
    SANDSTONE, GRANITE, MARBLE, ICE, IRON, OAK, ALUMINUM, TITANIUM
from .validation import Network, Coordinate, is_valid_submission, \
    check_with_chamber, calc_distance_between_coords


class NodeType(IntEnum):
    STEEL = 1
    ROCK = 2
    START = 3
    END = 4


class StructureType(IntEnum):
    BRIDGE = 1
    ROCK = 2


class InputFileType(IntEnum):
    RAW = 0
    CSV = 1
    XML = 2
    JSON = 3
    YAML = 4
    TXT1 = 5
    TXT2 = 6
    TSV = 7


Node = namedtuple('Node', ['number', 'x', 'y', 'type'])


def calculate_area(cross_section: BeamXn, dimensions: List[float]):
    if cross_section == BeamXn.CIRCLE:
        area = pi * dimensions[0] ** 2.
    elif cross_section == BeamXn.CYLINDER:
        area = pi * max(dimensions) ** 2. - pi * min(dimensions) ** 2.
    elif cross_section == BeamXn.RECTANGLE:
        area = dimensions[0] * dimensions[1]
    elif cross_section == BeamXn.RECTANGLETUBE:
        width, height = dimensions[0], dimensions[1]
        t1, t2, t3, t4 = dimensions[2], dimensions[3], \
            dimensions[4], dimensions[5]
        area = width * height - (width - t1 - t2) * (height - t3 - t4)
    else:
        raise NotImplementedError(f'Unrecognised cross-section '
                                  f'type {cross_section}')
    return area


def degrees_to_radians(theta: float) -> float:
    return theta * pi / 180.


def load_level(level: int):
    data = files(chambers).joinpath(f'geometry_level_{level}.json')
    level = json.loads(data.read_text())
    grid_size = level['grid_size']
    portals = [Coordinate(n[0], n[1]) for n in level['entry/exit']]
    fixed_nodes = [Coordinate(n[0], n[1])
                   for n in level['chamber']['fixed nodes']]
    return grid_size, portals, fixed_nodes


def rotate_coordinates(nodes: List[Coordinate], rotation: float):
    rotation = degrees_to_radians(rotation)
    rotated_nodes = []
    for node in nodes:
        x = node.x * cos(rotation) - node.y * sin(rotation)
        y = node.y * cos(rotation) + node.x * sin(rotation)
        new = Coordinate(int(round(x)), int(round(y)))
        rotated_nodes.append(new)
    return rotated_nodes


@dataclass
class Beam:
    start: Node
    end: Node
    number: int = None
    material: int = None
    _length: float = None

    def __str__(self):
        return f'Beam {self.number: <3}: ' \
               f'{self.start.number: ^3} - {self.end.number: ^3}'

    @property
    def length(self):
        if self._length is None:
            length = calc_distance_between_coords((self.start.x, self.start.y),
                                                  (self.end.x, self.end.y))
            self._length = length
        return self._length


@dataclass
class Structure:
    beams: List[Beam]
    type: StructureType
    load_path: List[Node]
    _nodes: Set[Node] = None

    @property
    def nodes(self):
        if self._nodes is None:
            nodes = set()
            for beam in self.beams:
                nodes.add(beam.start)
                nodes.add(beam.end)
            self._nodes = nodes
        return self._nodes

    @classmethod
    def from_attempt(cls, data: Dict[str, Union[List[List[int]], List[int]]],
                     provided_nodes: Dict[int, Node]):
        node_list = data['nodes']
        beam_list = data['beams']
        nodes = {}
        beams = []
        for n in node_list:
            new = Node(n[0], n[1], n[2], NodeType.STEEL)
            nodes[n[0]] = new
        for b in beam_list:
            if b[0] in nodes:
                start = nodes[b[0]]
            else:
                start = provided_nodes[b[0]]
                nodes[b[0]] = start
            if b[1] in nodes:
                end = nodes[b[1]]
            else:
                end = provided_nodes[b[1]]
                nodes[b[1]] = end
            new = Beam(start, end)
            beams.append(new)

        load_path = [nodes[j] for j in data['load_path']]
        structure = cls(beams, StructureType.BRIDGE, load_path)
        return structure

    @property
    def fixed_nodes(self) -> Set[Node]:
        fixed_nodes = {n for n in self.nodes if
                       n.type in [NodeType.ROCK, NodeType.START, NodeType.END]}
        return fixed_nodes


@dataclass
class Chamber:
    dimension: int
    rocks: Set[Node]
    start: Node
    end: Node
    load: float

    @property
    def rock_coordinates(self) -> List[Coordinate]:
        return [Coordinate(n.x, n.y) for n in self.rocks]

    def render_as_ascii(self) -> str:
        # Rotate by 90 to shift origin from upper left to lower left
        fixed_nodes = rotate_coordinates(self.rock_coordinates, 90.)
        doors = rotate_coordinates([Coordinate(self.start.x, self.start.y),
                                    Coordinate(self.end.x, self.end.y)], 90.)
        door1, door2 = doors
        n0 = (self.dimension - 1) // 2
        blank_grid = [['·' for i in range(self.dimension)] for j in
                      range(self.dimension)]
        for i in range(self.dimension):
            for j in range(self.dimension):
                for node in fixed_nodes:
                    if node.x + n0 == i and node.y + n0 == j:
                        blank_grid[i][j] = 'o'
                if door1.x + n0 == i and door1.y + n0 == j:
                    blank_grid[i][j] = '1'
                if door2.x + n0 == i and door2.y + n0 == j:
                    blank_grid[i][j] = '2'

        rows = ['  '.join(row) for row in blank_grid]
        rows = rows
        return '\n'.join(rows)

    @property
    def id(self):
        ordered_nodes = [n for n in self.fixed_nodes]
        ordered_nodes.sort(key=lambda n: n.number)
        strings_of_nodes = [f'{n.number}.{n.x}.{n.y}' for n in ordered_nodes]
        unique_string = f'{self.dimension}:' + '|'.join(strings_of_nodes)
        return hash(unique_string)

    def problem_statement(self):
        problem_template = files(story).joinpath('problem.txt').read_text()
        chamber_template = files(story).joinpath('chamber.txt').read_text()
        problem_template = Template(problem_template)
        chamber_template = Template(chamber_template)
        problem = problem_template.substitute(chamber_no=self.dimension)
        chamber = chamber_template.substitute(
            ascii_chamber_drawing=self.render_as_ascii(),
            start=self.start,
            end=self.end,
            xmin=-((self.dimension - 1) // 2),
            xmax=((self.dimension - 1) // 2),
            ymin=-((self.dimension - 1) // 2),
            ymax=((self.dimension - 1) // 2),
            num_lives=STARTING_LIVES
        )
        message = problem + chamber
        rocks = []
        for node in self.rocks:
            rocks.append(f'\n{node}')
        include = ''.join(rocks)
        message += f'\n{include}\n\nGood Luck!\n'
        return message

    def create_input_file(self, type_: InputFileType):
        all_nodes = [self.start, self.end] + list(self.rocks)
        if type_ == InputFileType.TXT1:
            lines = [f'{self.dimension}']
            for node in all_nodes:
                line = f'\n{node.number} {node.x} {node.y}'
                lines.append(line)

        elif type_ == InputFileType.RAW:
            lines = [f'N = {self.dimension}']
            for node in all_nodes:
                line = f'\n{node}'
                lines.append(line)
        else:
            raise NotImplementedError
        with open('./challenge_input.txt', 'w') as f:
            f.writelines(lines)

    @property
    def fixed_nodes(self):
        nodes = set()
        nodes.update(self.rocks)
        nodes.add(self.start)
        nodes.add(self.end)
        return nodes


@dataclass
class Simulation:
    mapdl: _MapdlCore = None
    nodes: Dict[int, Node] = None
    elements: List[Beam] = None
    load_path: List[Node] = None
    cross_section: BeamXn = None
    dimensions: List[float] = None
    _score: float = None
    _hard_mode: bool = False
    figure: plt.Figure = None
    axes: plt.Axes = None

    def setup(self):
        mapdl = launch_mapdl(override=True)
        mapdl.clear()
        mapdl.prep7()
        mapdl.units("SI")  # SI - International system (m, kg, s, K).
        self.mapdl = mapdl
        return mapdl

    def check_beam_lengths(self):
        valid = True
        reasons = []
        for beam in self.elements:
            diff_x = (beam.start.x - beam.end.x) ** 2
            diff_y = (beam.start.y - beam.end.y) ** 2
            distance = sqrt(diff_x + diff_y)
            if abs(distance) > MAX_EDGE_LENGTH:
                valid = False
                reasons.append(
                    f'beam {beam} is too long; length {distance} should'
                    f' be no longer than {sqrt(2.)}')
        return valid, reasons

    def calculate_score(self, materials: List[int]):
        area = calculate_area(self.cross_section, self.dimensions)
        masses = [area * b.length * MATERIALS[id_].density for b, id_ in
                  zip(self.elements, materials)]
        mass = sum(masses)
        return mass

    def calculate_cost(self, materials: List[int]):
        area = calculate_area(self.cross_section, self.dimensions)
        costs = [area * b.length * MATERIALS[id_].density * MATERIALS[
            id_].price_per_kg for b, id_ in
                 zip(self.elements, materials)]
        cost = sum(costs)
        return cost

    def construct_nodes(self, nodes: Iterable[Node]):
        if self.nodes is None:
            self.nodes = {self.mapdl.n(node.number, node.x, node.y, 0): node
                          for node in nodes}
        for node in nodes:
            if node.number not in self.nodes:
                self.nodes[self.mapdl.n(node.number, node.x, node.y, 0)] = node

    def construct_beams(self, beams: Iterable[Beam], materials: List[int]):
        if self.elements is None:
            self.elements = []
        for beam, m in zip(beams, materials):
            self.mapdl.mat(m)
            beam.number = self.mapdl.e(beam.start.number, beam.end.number)
            self.elements.append(beam)

    def clear_beams(self):
        self.mapdl.esel('ALL')
        self.mapdl.edele('ALL')

    def set_materials(self, shape: BeamXn, dimensions: List[float]):
        self.mapdl.et(1, "BEAM188")
        self.cross_section = shape
        self.dimensions = dimensions
        if self.cross_section == BeamXn.CIRCLE:
            self.mapdl.sectype(1, "BEAM", "CSOLID")
            # radius
            self.mapdl.secdata(dimensions[0])
        elif self.cross_section == BeamXn.CYLINDER:
            self.mapdl.sectype(1, "BEAM", "CTUBE")
            # inner radius, outer radius
            self.mapdl.secdata(dimensions[0],
                               dimensions[1])
        elif self.cross_section == BeamXn.RECTANGLETUBE:
            self.mapdl.sectype(1, "BEAM", "HREC")
            # width, height, WEST thickness, EAST thickness,
            # SOUTH thickness, NORTH thickness
            self.mapdl.secdata(dimensions[0],
                               dimensions[1],
                               dimensions[2],
                               dimensions[3],
                               dimensions[4],
                               dimensions[5])
        elif self.cross_section == BeamXn.RECTANGLE:
            self.mapdl.sectype(1, "BEAM", "RECT")
            self.mapdl.secdata(dimensions[0],
                               dimensions[1])
        # We just need to supply EX; APDL assumes isotropy if we do
        for id_, material in MATERIALS.items():
            self.mapdl.mp("EX", id_, material.elastic_modulus)
            self.mapdl.mp("PRXY", id_, material.poissons_ratio)

    def construct_chamber(self, chamber: Chamber):
        self.construct_nodes(list(chamber.fixed_nodes))
        self.lock_fixed_nodes(chamber.fixed_nodes)

    def make_attempt(self,
                     data: Dict[str, List[List[Union[int]]]],
                     chamber) -> Tuple[bool, str, float, float]:
        bridge = Structure.from_attempt(data,
                                        {n.number: n
                                         for n in chamber.fixed_nodes})
        self.construct_nodes(bridge.nodes)
        if 'materials' in data:
            materials = data['materials']
        else:
            materials = [1 for i in bridge.beams]
        self.construct_beams(bridge.beams, materials=materials)
        valid, reasons = self.check_beam_lengths()
        if not valid:
            return True, '\n'.join(['Attempt halted. Invalid beams.']
                                    + reasons), -1., -1.
        mass = self.calculate_score(materials)
        cost = self.calculate_cost(materials)
        self.apply_force(bridge, chamber, mass)
        self.solve()
        breakage, string = self.post_process(materials)
        self.mapdl.exit()
        string = string + f'\n\n Your bridge masses: {mass:3.3g} Kg\n'
        string = string + f'\n\n Your bridge costed: ${cost:3.3g}\n'
        return not breakage, string, mass, cost

    def solve(self):
        self.mapdl.run("/SOLU")
        out = self.mapdl.solve()
        self.mapdl.finish()

    def apply_force(self, bridge: Structure, chamber: Chamber,
                    bridge_mass: float):
        total_load = chamber.load
        if self._hard_mode:
            total_load = total_load + \
                         (bridge_mass / len(bridge.load_path)) * 9.81
        self.load_path = []
        for node in bridge.load_path:
            self.load_path.append(node)
            self.mapdl.f(node.number, "Fy", abs(total_load) * -1.)

    def lock_fixed_nodes(self, nodes: Iterable[Node]):
        for node in nodes:
            self.mapdl.d(node.number, "ALL")

    def post_process(self, materials: List[int]):
        self.mapdl.post1()
        breakage, string = self.assess_for_breaks(materials, True)
        return breakage, string

    def assess_for_breaks(self, materials: List[int], plot=False):
        self.mapdl.set('LAST')
        failed_elements = []
        breakage = False
        for beam, mat_id in zip(self.elements, materials):
            yield_str = MATERIALS[mat_id].yield_strength
            equiv = self.mapdl.get_value('secr', beam.number,
                                         's', 'eqv', 'max')
            percentage_diff = 100. * equiv / yield_str
            if abs(equiv) > yield_str:
                failed_elements.append((beam, True, equiv, percentage_diff))
            else:
                failed_elements.append((beam, False, equiv, percentage_diff))
        num_failures = len([i for i in failed_elements if i[1]])
        string_result = [
            f'Beam Failures: {num_failures} out of {len(failed_elements)}'
        ]
        for element in failed_elements:
            if element[1]:
                addendum = '- BREAK'
            else:
                addendum = ''
            string_result.append(f'{element[0]}: {element[-1]:g} % '
                                 f'of yield {addendum}')
        if plot:
            self.plot_result(failed_elements)

        if num_failures > 0:
            string_result.append(f'{"BRIDGE BREAKS":*^30}')
            breakage = True
        return breakage, '\n'.join(string_result)

    def plot_result(self, failed_elements):
        fig = plt.figure()
        ax = fig.add_subplot()
        self.figure = fig
        self.axes = ax
        ax.set_aspect(1)
        cmap = cm.viridis.copy()
        cmap.set_over('pink')
        divider = make_axes_locatable(ax)
        cax = divider.append_axes("top", size="5%", pad=0.5)
        for e in failed_elements:
            beam = e[0]
            color = cmap(e[-1] / 100.)
            ax.plot([beam.start.x, beam.end.x], [beam.start.y, beam.end.y],
                    color=color, linewidth=8)
        x_bridge_nodes = []
        y_bridge_nodes = []
        x_start_node = []
        y_start_node = []
        x_end_node = []
        y_end_node = []
        x_rocks = []
        y_rocks = []
        for num, node in self.nodes.items():
            if node.type == NodeType.STEEL:
                x_bridge_nodes.append(node.x)
                y_bridge_nodes.append(node.y)
            elif node.type == NodeType.ROCK:
                x_rocks.append(node.x)
                y_rocks.append(node.y)
            elif node.type == NodeType.START:
                x_start_node.append(node.x)
                y_start_node.append(node.y)
            elif node.type == NodeType.END:
                x_end_node.append(node.x)
                y_end_node.append(node.y)
        ax.plot(x_bridge_nodes, y_bridge_nodes, linestyle=' ',
                marker='D', color='gray', label='Bridge', ms=5, mfc='w',
                mew=2)
        ax.plot(x_start_node, y_start_node, linestyle=' ',
                marker=5, color='crimson', label='START', ms=8)
        ax.plot(x_end_node, y_end_node, linestyle=' ',
                marker=4, color='crimson', label='END', ms=8)
        ax.plot(x_rocks, y_rocks, linestyle=' ',
                marker='h', color='brown', label='Rocks',
                ms=10, mfc='w', mew=3)
        x_load_path = [n.x for n in self.load_path]
        y_load_path = [n.y for n in self.load_path]
        ax.plot(x_load_path, y_load_path, marker=' ', linestyle='-',
                color='crimson', label='load path')
        ax.set_xlabel('x [m]')
        ax.set_ylabel('y [m]')
        ax.legend(loc='best')
        norm = mpl.colors.Normalize(vmin=0., vmax=100.)
        cb = fig.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=cmap),
                          cax=cax, orientation='horizontal',
                          label='Percentage of Yield (%)', extend='max')


@dataclass
class Game:
    """Instance of the challenge. You can submit attempts and look at the
    challenge input via this class"""
    _chamber: Chamber = None
    _is_tutorial: bool = False
    _in_notebook: bool = False
    _current_level: int = None
    __log_path: pathlib.Path = pathlib.Path('./.attempt_logs/')
    __counter: int = STARTING_LIVES
    _figure: plt.figure = None
    _axes: plt.Axes = None

    def _load_level(self, level: int):
        self._current_level = level
        n, doors, rocks = load_level(level)
        start = Node(1, doors[0].x, doors[0].y, NodeType.START)
        end = Node(2, doors[1].x, doors[1].y, NodeType.END)
        nodes = {Node(n ** 2 + 1 + i, p.x, p.y, NodeType.ROCK) for i, p in
                 enumerate(rocks)}
        chamber = Chamber(n,
                          set(nodes),
                          start,
                          end,
                          9.81 * 1000.)
        self._chamber = chamber

    @property
    def is_tutorial(self):
        """Return True if in the tutorial mode."""
        return self._is_tutorial

    def display_challenge(self):
        """Print the challenge problem statement."""
        challenge = self._chamber.problem_statement()
        print(challenge)

    def generate_challenge_input(self):
        """Saves an input file as a text file in your working directory."""
        self._chamber.create_input_file(type_=InputFileType.TXT1)

    def _display_feedback(self, string: str):
        preamble = f'{" ": ^50}\n{"RESULTS":=^50}\n{" ": ^50}\n\n'
        string = preamble + string
        print(string)

    @property
    def lives_remaining(self):
        """How many lives you have left."""
        if self.is_tutorial:
            self.__counter = STARTING_LIVES
        return self.__counter

    def submit_attempt(self,
                       submission: Dict[
                           str, Union[List[int],
                                      List[float],
                                      List[List[int]],
                                      BeamXn]
                       ],
                       hard_mode: bool = False):
        """Submit an attempt.

        If your submission does not pass the validation
        step, it does not count as a life lost. A life is only lost if the
        bridge simulation completes and the bridge breaks.
        """
        valid, reasons = is_valid_submission(submission)
        rocks = [[n.number, n.x, n.y] for n in self._chamber.rocks]
        if valid:
            valid, reasons_chamber = check_with_chamber(submission, rocks)
            reasons.extend(reasons_chamber)
        if not valid:
            print('Invalid Submission')
            print('\n'.join(reasons))
            return
        network = Network.from_attempt(submission,
                                       [self._chamber.start.x,
                                        self._chamber.start.y],
                                       [self._chamber.end.x,
                                        self._chamber.end.y],
                                       rocks,
                                       self._chamber.dimension)
        valid, reasons = network.is_load_path_valid(
            self._chamber.rock_coordinates
        )
        if not valid:
            print('Invalid Load Path')
            print('\n'.join(reasons))
            return
        valid, problems = network.are_nodes_on_grid()
        if not valid:
            print('Invalid nodes')
            print('Nodes outside of grid limits:')
            for node in problems:
                print(f'- {node}')
            return
        success, string, score, cost = self._carry_out_attempt(submission,
                                                               hard_mode)
        self._display_feedback(string)
        if not success:
            print(f'{"YOU DIED":-^50}')
            print(f'You have {self.lives_remaining} lives remaining.')
            if self.lives_remaining == 0:
                print(f'{"GAME OVER":-^50}')

        if not self._is_tutorial:
            self._log_attempt(submission, string, score, cost, success)
        self.__counter -= 1
        if self.__counter < 0:
            self.__counter = STARTING_LIVES

    def _log_attempt(self, submission, feedback: str, score: float,
                     cost: float,
                     success: bool):
        self.__log_path.mkdir(exist_ok=True)
        submission['UUID'] = str(uuid.uuid4())
        submission['score'] = score
        submission['cost'] = cost
        submission['feedback'] = feedback
        attempt_log = self.__log_path / 'stats.json'
        if attempt_log.exists():
            with open(attempt_log, 'r') as f:
                data = json.load(f)
        else:
            data = {
                "GAME OVER count": 0,
                "Total No. Attempts": 0,
                "Best Score": 9.99e100 if not success else submission['score'],
                "Solution UUID": "" if not success else submission['UUID']
            }
        data['Total No. Attempts'] += 1
        if self.lives_remaining == 0:
            data['GAME OVER count'] += 1
        if success and data['Best Score'] > submission['score']:
            data['Best Score'] = submission['score']
            data['Solution UUID'] = submission['UUID']
        with open(attempt_log, 'w') as f:
            json.dump(data, f)
        submission_path = self.__log_path / f'{submission["UUID"]}.json'
        with open(submission_path, 'w') as f:
            json.dump(submission, f)

    def _show_stats(self) -> None:
        if self.__log_path.is_dir():
            with open(self.__log_path / 'stats.json', 'r') as f:
                data = json.load(f)
            print(json.dumps(data, sort_keys=True, indent=4))
        else:
            print('No stats to display')

    def _get_previous_submissions(self):
        submissions = {}
        if self.__log_path.is_dir():
            for file_name in self.__log_path.glob('*.json'):
                if not file_name.stem == 'stats':
                    with open(file_name) as f:
                        submission = json.load(f)
                    submissions[submission['UUID']] = submission
        return submissions

    def _carry_out_attempt(self, data, hard_mode: bool = False):
        sim = Simulation(_hard_mode=hard_mode)
        mapdl = sim.setup()
        sim.set_materials(data['cross-section'], data['dimensions'])
        sim.construct_chamber(self._chamber)
        mass = None
        success = False
        try:
            success, string, mass, cost = sim.make_attempt(data, self._chamber)
        except Exception as error:
            string = str(error)
            mapdl.exit()
        mapdl.exit()
        self._figure, self._axes = sim.figure, sim.axes
        return success, string, mass, cost

    def get_plot_figure_and_axes(self) -> Tuple[plt.Figure, plt.Axes]:
        """Return matplotlib figure and axes of last plot."""
        return self._figure, self._axes


def _generate_game(tutorial: bool = False):
    return Game(_is_tutorial=tutorial)


def play(tutorial: bool = False):
    """Create a Game instance with which you can tackle the
    codefest challenge."""
    game = _generate_game(tutorial)
    if tutorial:
        game._load_level(0)
    else:
        game._load_level(4)
    return game


if __name__ == '__main__':
    play()
